// N-Queens Visualizer - Coding Part
// Core Backtracking Implementation

let N = 8;
let board = [];
let stopped = false;
let decisions = 0;
let conflicts = 0;
let solutions = 0;

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Check whether a queen can safely be placed
function safe(row, col) {
  for (let r = 0; r < row; r++) {
    const c = board[r];

    // Same column or same diagonal
    if (
      c === col ||
      Math.abs(c - col) === Math.abs(r - row)
    ) {
      return false;
    }
  }

  return true;
}

// Backtracking algorithm
async function backtrack(row) {
  if (stopped) return;

  // All queens have been placed
  if (row === N) {
    solutions++;
    document.getElementById("solutions").textContent = solutions;
    return;
  }

  // Try every column in the current row
  for (let col = 0; col < N; col++) {
    if (stopped) return;

    decisions++;
    document.getElementById("steps").textContent = decisions;

    if (safe(row, col)) {
      // Place queen
      board[row] = col;
      render();

      await sleep(45);

      // Move to the next row
      await backtrack(row + 1);

      // Undo placement (backtracking)
      board[row] = -1;
      render();

      await sleep(35);
    } else {
      // Position causes a conflict
      conflicts++;
      document.getElementById("conflicts").textContent = conflicts;

      render(row, col);
      await sleep(18);
      render();
    }
  }
}

// Start the solver
async function solve() {
  stopSolve();

  stopped = false;
  solutions = 0;
  decisions = 0;
  conflicts = 0;

  N = Math.max(
    4,
    Math.min(
      10,
      parseInt(document.getElementById("n").value) || 8
    )
  );

  board = Array(N).fill(-1);

  document.getElementById("solutions").textContent = 0;
  document.getElementById("steps").textContent = 0;
  document.getElementById("conflicts").textContent = 0;

  const start = performance.now();

  document.getElementById("status").textContent =
    "Backtracking in progress...";

  await backtrack(0);

  document.getElementById("time").textContent =
    Math.round(performance.now() - start) + " ms";

  document.getElementById("status").textContent =
    stopped
      ? "Stopped by user."
      : `Finished: ${solutions} solution(s) found.`;
}

// Stop the algorithm
function stopSolve() {
  stopped = true;
}

// Clear the board
function clearBoard() {
  stopSolve();
  board = Array(N).fill(-1);

  document.getElementById("status").textContent =
    "Board cleared.";

  document.getElementById("solutions").textContent = 0;
  document.getElementById("steps").textContent = 0;
  document.getElementById("conflicts").textContent = 0;
  document.getElementById("time").textContent = "0 ms";

  render();
}
