# N-Queens Visualizer — DAA Hackathon Problem 10

## Problem
Visualize how queens are placed safely on a chessboard. Show conflicts, backtracking decisions, number of solutions and execution statistics.

## Algorithm
Backtracking: place one queen row-by-row, check whether the position is safe, continue recursively, and undo the placement when it cannot lead to a valid solution.

## Features
- N from 4 to 10
- Animated backtracking
- Conflict visualization
- Number of solutions
- Decision/conflict counters
- Execution time
- Stop and Clear controls

## Run
Open `index.html` directly in a modern browser. No server or external library is required.

## Submission files
- `index.html` — implementation
- `NQueens_Visualizer_Report.docx` — report
- `NQueens_Visualizer_PPT.pptx` — presentation
